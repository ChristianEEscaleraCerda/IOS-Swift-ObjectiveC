//
//  ViewController.swift
//  appConjunotsIOS
//
//  Created by Guest User on 12/05/22.
//

import UIKit

class ViewController: UIViewController {

    var setA = Set<String>()
    var setB = Set<String>()
    
    
    @IBOutlet weak var textoCA: UITextField!
    @IBOutlet weak var textoCB: UITextField!
    
    
    @IBOutlet weak var labResultado: UILabel!
    
    @IBOutlet weak var butSetA: UIButton!
    
    @IBOutlet weak var butSetB: UIButton!
    
    
    @IBAction func butAsignarA(_ sender: Any) {
        // Validar que haya Datos
        //if textoCA.text!.count > 0
        if(!textoCA.text!.isEmpty){
            let cadena: [String] = (textoCA.text!.components(separatedBy: ","))
            setA = Set<String>()
            for valor in cadena {
                setA.insert(valor)
            }
            
    }
        setA.remove("")
        textoCB.isEnabled = true
        textoCB.becomeFirstResponder()
        butSetB.isEnabled = true
    }
  
    @IBAction func butAsignarB(_ sender: Any) {
        if(!textoCB.text!.isEmpty){
            let cadena: [String] = (textoCB.text!.components(separatedBy: ","))
            setB = Set<String>()
            for valor in cadena {
                setB.insert(valor)
            }
          }
    }
    
    @IBAction func butInterseccion(_ sender: Any) {
        
        let inters = setA.intersection(setB).sorted()
        let res = [String](inters)
        labResultado.text = res.joined(separator: ",")
        
    }
    
    @IBAction func butUnion(_ sender: Any) {
        let unionAB = setA.union(setB)
        let res = [String](unionAB)
        labResultado.text = res.joined(separator: ",")
        
    }
    
    @IBAction func butResta(_ sender: Any) {
        let resta = setA.subtracting(setB)
        let res = [String](resta)
        labResultado.text = res.joined(separator: ",")
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
      
        
    }


    
}

