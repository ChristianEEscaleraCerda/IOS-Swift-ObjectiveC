//
//  main.m
//  appRegex
//
//  Created by Guest User on 30/03/22.
//

#import <Foundation/Foundation.h>
#import <iostream>
 using namespace std;

int main(int argc, const char * argv[]) {
    @autoreleasepool {
      
        //NSString *cadenaPrueba = @"8Tecnològico @ de la laguna, Av 45" ;
        
        //CAPTURAR LA CADENA
        printf("Cadena a Analizar");
        char cadena[255];
        cin.getline(cadena, 255);
        
        NSString *cadenaPrueba = [NSString stringWithCString:cadena encoding:NSASCIIStringEncoding];
        
        NSLog(@"Cadena de prueba : %@",cadenaPrueba);
        NSError *error = nil;
        
        NSMutableString *cadenaPatron = [[NSMutableString alloc]init];
        
       // [cadenaPatron appendString:@"\\b(a|b)(c|d)\\b"];
        //VOCALES
       // [cadenaPatron appendString:@"([aeiou])"];
        
        //[cadenaPatron appendString:@"[0-9]"];
       // [cadenaPatron appendString:@"\\d"];
        [cadenaPatron appendString:@"\\d+"];
        
        
        NSRegularExpression *regex = [NSRegularExpression regularExpressionWithPattern:cadenaPatron options:NSRegularExpressionCaseInsensitive error:&error];
        
        NSArray *matches = [regex matchesInString:cadenaPrueba options:0 range:NSMakeRange(0, cadenaPrueba.length)];
        
        for( NSTextCheckingResult *matchResult in matches){
            
            NSString *match = [cadenaPrueba substringWithRange:matchResult.range];
            NSLog(@"Coincidencia = @%@", match);
        }
        
    }
    return 0;
}
