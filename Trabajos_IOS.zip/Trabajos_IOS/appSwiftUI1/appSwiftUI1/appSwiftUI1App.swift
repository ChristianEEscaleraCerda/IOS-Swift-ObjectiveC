//
//  appSwiftUI1App.swift
//  appSwiftUI1
//
//  Created by Guest User on 31/05/22.
//

import SwiftUI

@main
struct appSwiftUI1App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
