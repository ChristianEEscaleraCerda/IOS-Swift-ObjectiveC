//
//  ContentView.swift
//  appSwiftUI1
//
//  Created by Guest User on 31/05/22.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack( spacing: 30){
            Text("Hola, Tec Laguna").fontWeight(.light)
                .foregroundColor(.blue).multilineTextAlignment(.center)
                .padding(.vertical, 12.0)
                .font(.title3)
                
            Text("Torreon").fontWeight(.black)
                .foregroundColor(.yellow)
            Text("*Este texto es bold **bold**, este texto es texto *italic*, Este texto es  ***bold,  italic*** ")
            Text("~~Uso de strikethrough~~")
                
            
        }
        
        
           
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}







