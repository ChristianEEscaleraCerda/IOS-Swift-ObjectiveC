//
//  main.swift
//  appArreglos
//
//  Created by Guest User on 02/05/22.
//

import Foundation

var numerosAleatorios:Int
var arreglo : [Int] = [ ]
for _ in 1...10
{
    numerosAleatorios = Int.random(in: 1...100)
    arreglo.append(numerosAleatorios)
    
}

print(arreglo)

var arregloAux : [Int]=[]
arregloAux = arreglo

arreglo.shuffle()
print("Arreglo Utilizando el mètodo Shuffle")
print(arreglo)
arregloAux = arreglo.sorted(by: >)
print(arregloAux)
print("\nAPlicar el Metodo Burbuja para Ordenar los Datos de Arreglo")

var aux2 :Int

for _ in 0...arreglo.count
{
    for j in (1...arreglo.count-1).reversed()
    {
        
        if(arreglo[j-1] > arreglo[j]){
            let aux2 = arreglo[j-1]
            arreglo[j-1] = arreglo[j]
            arreglo[j] = aux2
            
        }
    }
}

print("\n Arreglo Ordenado con Burbuja")
print(arreglo)
