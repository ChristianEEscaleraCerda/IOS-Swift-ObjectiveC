//
//  ContentView.swift
//  appTextField
//
//  Created by Guest User on 01/06/22.
//

import SwiftUI

struct ContentView: View {
    
    @State var entrada: String = ""
    var body: some View {
        Group {
            TextField("Escribe algun texto", text: $entrada)
                .frame(width: 200, height: 100, alignment: .center)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .foregroundColor(.red)
            
            
            if !entrada.isEmpty
            {
                Text("Tu texto : "+entrada)
            }
                
        }
}
}
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
