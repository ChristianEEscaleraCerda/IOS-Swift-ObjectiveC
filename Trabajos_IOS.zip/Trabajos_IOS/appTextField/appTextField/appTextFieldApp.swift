//
//  appTextFieldApp.swift
//  appTextField
//
//  Created by Guest User on 01/06/22.
//

import SwiftUI

@main
struct appTextFieldApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
