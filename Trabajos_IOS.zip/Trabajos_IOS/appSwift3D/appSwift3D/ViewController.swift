//
//  ViewController.swift
//  appSwift3D
//
//  Created by Guest User on 24/05/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var imageView: UIImageView!
    
    @IBOutlet weak var sliderCamaraX: UISlider!
    
    @IBOutlet weak var textoValX: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

