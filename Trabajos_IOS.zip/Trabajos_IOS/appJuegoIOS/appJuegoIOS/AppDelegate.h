//
//  AppDelegate.h
//  appJuegoIOS
//
//  Created by Guest User on 08/04/22.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

