//
//  ContentView.swift
//  appSwiftUI
//
//  Created by Daniel Saldivar on 09/06/22.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack{
            Text("Selecciona el tipo de Pokemon")
                .foregroundColor(Color.yellow)
                .font(.custom("Lato-Bold", size: 20))
                .lineLimit(2)
                .allowsTightening(true)
                .frame(width: .infinity, alignment: .center)
            LazyVStack{
                CategoryCard("Veneno","El tipo veneno es frecuente en Pokémon; suele encontrarse en zonas donde hay cuevas, pantanos o en sus cercanías. Muchos Pokémon de este tipo pueden expulsar de sus cuerpos distintas sustancias nocivas como gases, ácidos, venenos, esporas u olores malolientes.",imageName:"veneno")
                CategoryCard("Bicho","Este grupo de Pokémon se caracteriza por su crecimiento rápido, ya que, en general, no tardan mucho en evolucionar. Viven primordialmente en los bosques y zonas cercanas a estos, algunos son un poco más difíciles de divisar debido a que se encuentran en copas de árboles donde anidan.",imageName:"bicho")
                CategoryCard("Fantasma","Los Pokémon que pertenecen al tipo fantasma generalmente se relacionan con el terror, lo oscuro y el más allá. Suelen vivir en casas abandonadas, cementerios, torres fúnebres y lugares oscuros e inhabitados. Gran parte de estos Pokémon esbozan una sonrisa siniestra y tenebrosa.",imageName:"fantasma")
                CategoryCard("Planta"," A los Pokémon de tipo planta les gusta cuidar de las flores y a los demás, pero también son grandes luchadores y son expertos en cambios de estado, pudiendo envenenar, paralizar o dormir al rival en combate, mientras que ellos son inmunes a drenadoras, y a movimientos con esporas y polvos.",imageName:"planta")
                CategoryCard("Siniestro","Como bien indica su nombre, representan la oscuridad y la maldad, asimismo, puede simplemente tratarse de criaturas más acostumbradas a la noche que al día. Los Pokémon de tipo siniestro son, en su mayoría, agresivos y misteriosos; por lo tanto, encontrar un tipo siniestro es un poco complicado.",imageName:"sinie")
            }
            Spacer()
        }.padding()
    }
}

struct CategoryCard: View {
    
    var title: String = ""
    var subtitle: String = ""
    var imageName: String = ""
    
    init(_ title: String, _ subtitle: String, imageName: String){
        self.title = title
        self.subtitle = subtitle
        self.imageName = imageName
    }
    var body: some View{
        HStack(alignment: .center, spacing: 0, content: {
            Image(imageName)
                .cornerRadius(16)
                
            VStack{
                Text(title)
                    .font(.custom("Lato-Bold", size: 16))
                    .foregroundColor(Color.primary)
                    .bold()
                    
                Text(subtitle)
                    .font(.custom("Lato-Bold", size: 13))
                    .foregroundColor(Color.secondary)
                                        
            }
        }).padding(EdgeInsets(top: 2, leading: 0, bottom:15,trailing: 0))
        .background((RoundedRectangle(cornerRadius: 16)
            .fill(Color.white)
            .shadow(radius:20, x:10, y:10))
            .foregroundColor(Color.gray))
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

