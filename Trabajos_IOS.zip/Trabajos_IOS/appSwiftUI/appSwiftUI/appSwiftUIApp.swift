//
//  appSwiftUIApp.swift
//  appSwiftUI
//
//  Created by Daniel Saldivar on 09/06/22.
//

import SwiftUI

@main
struct appSwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
