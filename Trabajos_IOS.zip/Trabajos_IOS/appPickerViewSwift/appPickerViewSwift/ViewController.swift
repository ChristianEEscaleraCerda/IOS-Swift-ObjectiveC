//
//  ViewController.swift
//  appPickerViewSwift
//
//  Created by Guest User on 17/05/22.
//

import UIKit

class ViewController: UIViewController,UIPickerViewDelegate, UIPickerViewDataSource {
    private func pickerView(_ pickerView: UIPickerView, widthForComponent component: Int) -> Int {
        return carrosColor[component].count
    }
    
    @IBOutlet weak var texto1: UITextField!
    
    let carrosColor = [["VW","Toyota","Honda","Nissan","Kia","Mazda", "MG","Ford"],["Blanco","Rojo","Azul","Verde","Gris"]]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let pickerView = UIPickerView()
        
        pickerView.delegate = self
        
        pickerView.center = view.center
        
        texto1.inputView  = pickerView
        
    }

    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 2
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        
        if(component == 0)
        {
        return self.carrosColor[component][row];
        }
        else{
        return self.carrosColor[component][row];
        }
        return nil;
        
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        let carro = carrosColor[0][pickerView.selectedRow(inComponent: 0)]
        
        let color = carrosColor[1][pickerView.selectedRow(inComponent:1)]
        
        texto1.text = carro + " " + color
        
        
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return carrosColor [component].count
    }
    
}

