//
//  main.swift
//  appEvED
//
//  Created by Guest User on 05/05/22.
//

import Foundation

class Node<T> {
  internal var data: T
  internal var next: Node<T>?
  init(data: T) {
    self.data = data
    self.next = nil
  }
}

class SinglyLinkedList<T> {
  internal var head: Node<T>?
  internal var count: Int = 0
    
  public init() {}
  
    init(first: Node<T>) {
    self.head = first
  }
    
    
    public func isEmpty() -> Bool {
        return count == 0
      }
      public func size() -> Int {
        // Regresa un contador del numero de elemntos en la lista
        return count
      }
      // adds an element at the beginning of the list
      public func add(element: T) {
        let node = Node<T>(data: element)
        node.next = head
        head = node
        count += 1
      }

      // removes and returns an element from the beginning of the list
      public func remove() -> T? {
        // Check if list is empty
        if isEmpty() {
          return nil
        }
        // get the data from the head
        let item = self.head?.data
        // move the head
        self.head = self.head?.next
        // decrease the count
        count -= 1
        return item
      }
    
    
    
    public func peek() -> T? {
      // if list is empty, return nil
      if isEmpty() {
        return nil
      }
      // otherwise return the data stored in head
      return head?.data
    }
    
     func  imprimir(){
        for i in 0...singlyLinkedList.count-1 {
            var a = singlyLinkedList.peek()!
            
            singlyLinkedList.remove()
            print(a,"->")
        }
        }
}


// instantiate a singly linked list to store integers
var singlyLinkedList = SinglyLinkedList<Int>()
// add two elements to it
singlyLinkedList.add(element: 22)
singlyLinkedList.add(element: 31)
singlyLinkedList.add(element: 11)
singlyLinkedList.add(element: 57)
singlyLinkedList.add(element: 64)

print("LISTA ENLAZADA")

// print the size and the head element
// prints "Size is 2"
print("Size is \(singlyLinkedList.size())")
// prints "Head is 3"

print("Head is \(singlyLinkedList.peek()!)")
// remove the first element
//singlyLinkedList.remove()
var eliminar = singlyLinkedList.remove()
//print("VALOR ELIMINADO : \(String(describing: eliminar))")
print("Valor eliminado : ",eliminar!)
// peek into the list again
// prints "New Head is 2"
print("New Head is \(singlyLinkedList.peek()!)")


//  EVALUACION:  IMPLEMENTAR EL METODO IMPRIMIR
singlyLinkedList.imprimir()


