//
//  main.m
//  appArchivos
//
//  Created by Guest User on 04/04/22.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // insert code here...
        NSString *string1 = @"ESTA ES una cadena.  &-_,;:¡!¿?^*+/%$";
                //ARCHIVOS CON OBJECTIVE-C
                //ESCRIBIR ARCHIVO
                NSMutableString *cadenaMut = [[NSMutableString alloc] initWithString:string1];
                NSLog(@"STRING 1 : %@",cadenaMut);
                //LEER NOMBRE DEL ARCHIVO
                NSString *nomArchivo = @"archOC1.txt";
                
                NSString *path = [NSHomeDirectory()
                                  stringByAppendingPathComponent:nomArchivo];

                NSLog(@"Path : %@",path);
    
                [cadenaMut writeToFile:path atomically:YES encoding:NSUTF8StringEncoding error:NULL];
                
                NSLog(@"\a\aARCHIVO GUARDADO");
                
                //LEER ARCHIVO
                NSError *error;
               
                NSString *str = [[NSString alloc]initWithContentsOfFile:path encoding:NSUTF8StringEncoding error:&error];
                 
                if(!str)
                    NSLog(@"FALLO LA LECTURA : %@",[error localizedDescription]);
                else
                    NSLog(@"Contenido Del Archivo = %@",str);
                
            }
            return 0;
        }

