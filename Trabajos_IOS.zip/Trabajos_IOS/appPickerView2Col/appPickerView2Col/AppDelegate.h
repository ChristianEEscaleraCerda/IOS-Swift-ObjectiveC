//
//  AppDelegate.h
//  appPickerView2Col
//
//  Created by Guest User on 06/04/22.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

