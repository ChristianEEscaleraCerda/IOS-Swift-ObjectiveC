//
//  ViewController.m
//  appPickerView2Col
//
//  Created by Guest User on 06/04/22.
//

#import "ViewController.h"

@interface ViewController ()
{
    NSArray *productos;
    NSArray *colores;
    
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    productos = @[@"Pikachu",@"Snivy",@"Oshawott",@"Tepig",@"Carro",@"Camioneta"];
    
    colores = @[@"Amarillo",@"Verde",@"Azul",@"Naranja",@"Gris",@"Aleatorio"];
    
    _picker1.dataSource = self;
    _picker1.delegate = self;
    
    
    //Cargar la informacion del primer producto
    _lab1.text = [NSString stringWithFormat:@" %@, %@ ",[productos objectAtIndex:0], [colores objectAtIndex:0]];
    
    UIColor *color = [UIColor colorWithRed:0 green:180 blue:150 alpha:1];
    
    self.view.backgroundColor = color;
    
    
    _imageView1.image = [UIImage imageNamed:@"PantallaLCD"];
    
    NSLog(@"%@ ", _lab1.text);
    
}

-(NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView{
    return 2;
}

-(NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
    if(component == 0){
        return productos.count;
    }else{
        return colores.count;
    }
}

-(NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component{
    if(component == 0)
        return [productos objectAtIndex:row];
    else
        return colores[row];
    return nil;
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    _lab1.text = [NSString stringWithFormat:@" %@ , %@", [productos objectAtIndex:[_picker1 selectedRowInComponent:0]], [colores objectAtIndex:[_picker1 selectedRowInComponent:1]]];
    
    int color = (int)[colores indexOfObject:[colores objectAtIndex:[_picker1 selectedRowInComponent:1]]];
    
    switch(color){
            
        case 0: _imageView1.backgroundColor = [UIColor yellowColor];
            _imageView1.image = [UIImage imageNamed:@"pikachu"];
            break;
        case 1: _imageView1.backgroundColor = [UIColor greenColor];
            _imageView1.image = [UIImage imageNamed:@"snivy"];
            break;
        case 2: _imageView1.backgroundColor = [UIColor blueColor];
            _imageView1.image = [UIImage imageNamed:@"osha"];
            break;
        case 3: _imageView1.backgroundColor = [UIColor orangeColor];
            _imageView1.image = [UIImage imageNamed:@"tepig"];
            break;
        case 4: _imageView1.backgroundColor = [UIColor yellowColor];
            _imageView1.image = [UIImage imageNamed:@"BICI_2"];
            break;
        case 5:
            srand((unsigned int) time(NULL));
            UIColor *color = [UIColor colorWithRed:(rand()%255 /255,0) green:(rand()%255 / 255,0) blue:rand()%255/255.0 alpha:1];
            
            _imageView1.backgroundColor=color;
            _imageView1.image = [UIImage imageNamed:@"camioneta1"];
            break;
    }
    
}

@end
