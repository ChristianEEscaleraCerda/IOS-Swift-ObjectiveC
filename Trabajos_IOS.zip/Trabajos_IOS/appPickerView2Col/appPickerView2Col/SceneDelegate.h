//
//  SceneDelegate.h
//  appPickerView2Col
//
//  Created by Guest User on 06/04/22.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

