//
//  ViewController.swift
//  appSwift1
//
//  Created by Guest User on 04/05/22.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var lab1: UILabel!
    
    var time = 0
    var timer = Timer()
    
    
    @IBAction func butIniciar(_ sender: UIButton) {
        timer = Timer.scheduledTimer(timeInterval: 0.5, target: self, selector: #selector(ViewController.accion ), userInfo: nil, repeats: true)
        
    }
    
    //DEFINICMOS  LA FUNCION ACCION
    @objc func accion()
    {
        time += 1
        lab1.text = String(time)
    }
    
    @IBAction func butDetener(_ sender: Any) {
        timer.invalidate()
    }
    
    @IBAction func butReiniciar(_ sender: Any) {
        time = 0
        lab1.text = String(time)
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    

}

