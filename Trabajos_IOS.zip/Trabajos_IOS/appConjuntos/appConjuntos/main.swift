//
//  main.swift
//  appConjuntos
//
//  Created by Guest User on 11/05/22.
//

import Foundation

let conjuntoVacio1: Set<Int> = []

print(conjuntoVacio1)

let conjuntoVacio2: Set<Int> = Set()
print(conjuntoVacio2)

var conjuntoA: Set = [1,2,3,4,5]
print(conjuntoA)

for val in conjuntoA
{
    print(val)
}
print()

var valor = conjuntoA.remove(6)
print(valor as Any)  //As Any es para que muestre aunque sea null

valor = conjuntoA.remove(3)
print("Valor eliminado :",valor!)

print("Ingresa el nùmero para eliminar")
var num = Int(readLine()!)

if let valor = conjuntoA.remove(num!)
{
    print("Valor eliminado :  \(valor)")
    print(conjuntoA)
}else {
    print("Elemento NO encontrado")
}

//Agregar Elemento


conjuntoA.insert(6)
print(conjuntoA)
var conjuntoB:Set<Int> = []
for _ in 1..<5
{
    conjuntoB.insert(Int(arc4random_uniform(10)))
}
print("Conjunto B")
print(conjuntoB)

print("Union")
print(conjuntoA.union(conjuntoB))

print("Interseccion")
print(conjuntoA.intersection(conjuntoB))

print("Diferencia Simetrica")
print(conjuntoA.symmetricDifference(conjuntoB))

print("Resta")
print(conjuntoA.subtracting(conjuntoB))


let animalesCasa: Set = ["🐶", "🐱"]
let animalesGranja: Set = ["🐮", "🐔", "🐑", "🐶", "🐱"]
let animalesCiudad: Set = ["🐦", "🐭"]

print("Animales de Casa: ", animalesCasa,"\n")
print("Animales de Granja: ", animalesGranja,"\n")

if animalesGranja.isSuperset(of: animalesCasa)
{
    print("Animales de Granja es Superconjunto de Animales de Casa")
}else{
    print("Animales de Granja NO es Superconjunto")
}

if animalesCasa.isSuperset(of: animalesGranja)
{
    print("Animales de Casa  es Superconjunto de Animales de granja")
}else{
    print("Animales de Casa NO es Superconjunto")
}

print("Frutas es Disjunto de animales :",conjuntoA.isDisjoint(with: animalesGranja))

