//
//  graficos2D.swift
//  appGraficos
//
//  Created by Guest User on 20/05/22.
//

import UIKit

class graficos2D: UIView {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.*/
   
    
    override func draw(_ rect: CGRect) {
       
        let canvas = UIGraphicsGetCurrentContext()
        
        canvas?.setLineWidth(5.0)
        
        //canvas?.setStrokeColor(UIColor.yellow.cgColor)
        
        let colorSpace = CGColorSpaceCreateDeviceRGB()
        let componentes:[CGFloat] = [CGFloat(Float.random(in: 0..<1)), CGFloat(drand48()),0.0,1.0]
        
        let color = CGColor(colorSpace: colorSpace, components: componentes)
        
        canvas?.setStrokeColor(color!)
        
        canvas?.move(to: CGPoint(x: 0, y: 0))
        canvas?.addLine(to: CGPoint.init(x: rect.width-10, y: rect.height-10))
        
        let ancho = rect.width
        let alto = rect.height
        canvas?.strokePath()
        
        print("Ancho = \(ancho)")
        print("Alto = \(alto)")
        
        let rectangulo = CGRect(x:50, y: 50, width:200, height:200)
                
                canvas?.addRect(rectangulo)
                canvas?.strokePath()
                
                //Rombo
                canvas?.move(to: CGPoint(x:200, y:200))
                canvas?.addLine(to: CGPoint(x:250, y:250))
                canvas?.addLine(to: CGPoint(x:200, y:300))
                canvas?.addLine(to: CGPoint(x:150, y:250))
                canvas?.addLine(to: CGPoint(x:200, y:200))
                canvas?.setFillColor(UIColor.red.cgColor)
                canvas?.fillPath()
                
                //DIBUJAR TEXTO
            
                //let font = UIFont.systemFont(ofSize: 30)
                 //   let font = UIFont(name: "Copperplate-Light", size: 30)
                let font = UIFont(name: "Arial", size: 30)
                    
                let stringAncho = NSAttributedString(string: "Ancho = \(ancho)", attributes: [NSAttributedString.Key.font: font!])
                stringAncho.draw(at: CGPoint(x: 10, y: 700))
                    
                let stringAlto = NSAttributedString(string: "Alto = \(alto)", attributes: [NSAttributedString.Key.font: font!])
                stringAlto.draw(at: CGPoint(x: 10, y: 750))

        
    }
    

}
