//
//  ViewController.swift
//  appJuego
//
//  Created by Guest User on 10/05/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var texto1: UITextField!
    
    
    @IBOutlet weak var labIntento: UILabel!
    
    @IBOutlet weak var labMensaje: UILabel!
    
    var numRandom = 0
    var intento = 0
    
    func incializar()
    {
        numRandom = Int(arc4random_uniform(10))
        texto1.text = ""
        intento = 3
        labIntento .text = String(intento)
        labMensaje.text = "Selecciona un numero del 0-9"
        let color = UIColor(red: 1.0, green: 0, blue: 0, alpha: 1.0)
        self.view.backgroundColor = color
        
        
    }
    
    
    @IBAction func butJugar(_ sender: UIButton) {
        if(texto1.text == String(5)) //Ahi va el random
        {
            labMensaje.text = "Ganaste!!!"
            self.view.backgroundColor = #colorLiteral(red: 0.2392156869, green: 0.6745098233, blue: 0.9686274529, alpha: 1)
        }
        else{
            if(intento==1)
            {
                labMensaje.text = "Fallaste :("
                self.view.backgroundColor = #colorLiteral(red: 0.9254902005, green: 0.2352941185, blue: 0.1019607857, alpha: 1)
                Alerta()
            }
            else{
                intento -= 1
                labIntento.text = String(intento)
                labMensaje.text = "Vuelve a intentarlo"
                texto1.text = ""
            }
        }
        
        
        
    }
    func Alerta()
    {
        let alerta = UIAlertController(title: "ALERTA", message: "Intentalo de nuevo",preferredStyle: .alert)
        
        let jugarOtraVez = UIAlertAction(title: "Juega de nuevo", style: .default)
        {
            (UIAlertAction) in self.incializar()
        }
        
        alerta.addAction(jugarOtraVez)
        self.present(alerta, animated: true, completion: nil)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func butReini(_ sender: Any) {
        self.viewDidLoad()
        incializar()
    }
    @IBAction func butTerminar(_ sender: Any) {
        UIControl().sendAction(#selector(NSXPCConnection.suspend), to: UIApplication.shared, for: nil)
    }
}

