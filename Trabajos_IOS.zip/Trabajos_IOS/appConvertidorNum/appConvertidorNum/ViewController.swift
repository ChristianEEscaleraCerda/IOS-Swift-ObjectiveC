//
//  ViewController.swift
//  appConvertidorNum
//
//  Created by Guest User on 09/05/22.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var text1: UITextField!
    
    
    @IBOutlet weak var slider: UISlider!
    
    
    @IBOutlet weak var segmento: UISegmentedControl!
    
    var num:Int?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        slider.value = 10
        
    }
    
    
    @IBAction func slider(_ sender: UISlider) {
        //Se redonde y sepasa al text field
        text1.text = "\(String(describing: lroundf(sender.value)))"
        
        num = Int(text1.text!)
        
    }
    

    @IBAction func segmento(_ sender: UISegmentedControl) {
        
        let indice : Int=segmento.selectedSegmentIndex
        
        switch indice {
        case 0:
            text1.text = String(num!, radix: 2)
            break
        case 1:
            text1.text = String(num!, radix: 8)
            break
        case 2:
            text1.text = String(num!, radix: 16)
            break
        default:
            
        }
        
        /*
        if indice == 0
        {
            text1.text = String(num!, radix: 2)
        }
        else if indice == 1
        {
            text1.text = String(num!, radix: 8)
        }
        else if indice == 2
        {
            text1.text = String(num!, radix: 16).uppercased()
        }*/
        
    }
}

