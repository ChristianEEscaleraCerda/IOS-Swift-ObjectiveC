import Cocoa

func mayorMenor(array: [Int]) -> (mayor: Int, menor: Int) {
   var mayor = array[0]
   var menor = array[0]
   for val in array[1..<array.count] {
      if val < menor {
        menor = val
      } else if val > mayor {
        mayor = val
      }
   }
   return (mayor, menor)
}

let num = mayorMenor(array: [45,88,34,99,785,42,-2])
print("El numero Mayor es: \(num.mayor) \n El nùmero Menor es : \(num.menor)")


func multiplicar(n1:Double, n2:Double)->Double
{
    return n1*n2
}
print(multiplicar(n1: 5.23 , n2: 3.54))


//Mostrar la cantidad de decimales especificos

print(String(format: "Salida con formato: %2.2lf", multiplicar(n1: 6.2, n2: 4.7)))
func potencia(argX x: Int, argY y: Int) -> Int {
   var resul = x
   for _ in 1..<y {
    resul = resul * x
   }
   print(resul)
   return resul
}
potencia(argX:2, argY:3)
