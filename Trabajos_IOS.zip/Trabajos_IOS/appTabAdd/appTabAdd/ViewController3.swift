//
//  ViewController3.swift
//  appTabAdd
//
//  Created by Daniel Saldivar on 09/06/22.
//

import UIKit

class ViewController3: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        self.view.backgroundColor = UIColor(patternImage: UIImage(named: "fondo2.jpg")!)
    }
    



}
