//
//  ViewController.swift
//  appTabAdd
//
//  Created by Guest User on 30/05/22.
//

import UIKit
import SceneKit

var tipoLuz:String?
class ViewController: UIViewController {

    
    @IBOutlet weak var ImageView: UIImageView!
    @IBOutlet weak var sliderCamaraX: UISlider!
    @IBOutlet weak var sliderCamZ: UISlider!
    @IBOutlet weak var sliderCamY: UISlider!
    @IBOutlet weak var textoValorX: UITextField!
    @IBOutlet weak var textoValZ: UITextField!
    @IBOutlet weak var textoValY: UITextField!
    
    @IBOutlet weak var segment: UISegmentedControl!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tipoLuz = "ambient"
        
        self.view.backgroundColor = UIColor(patternImage: UIImage(named: "fondo4.jpg")!)
    }
    
    @IBAction func sliderX(_ sender: UISlider) {
        
        
        if (segment.selectedSegmentIndex == 0 )
        {
            sliderCamaraX.value = sender.value
            textoValorX.text = String(sliderCamaraX.value)
            dibujaCubo()
        }
        else if (segment.selectedSegmentIndex == 1)
        {
            sliderCamaraX.value = sender.value
            textoValorX.text = String(sliderCamaraX.value)
            dibujaCapsula()
        }
        
        
    }
    
    @IBAction func sliderY(_ sender: UISlider) {
        if (segment.selectedSegmentIndex == 0 )
        {
            sliderCamY.value = sender.value
            textoValY.text = String(sliderCamY.value)
            dibujaCubo()
        }
        else if (segment.selectedSegmentIndex == 1)
        {
            sliderCamY.value = sender.value
            textoValY.text = String(sliderCamY.value)
            dibujaCapsula()
        }
    }
    
    @IBAction func sliderZ(_ sender: UISlider) {
        if (segment.selectedSegmentIndex == 0 )
        {
            sliderCamZ.value = sender.value
            textoValZ.text = String(sliderCamZ.value)
            dibujaCubo()
        }
        else if (segment.selectedSegmentIndex == 1)
        {
            sliderCamZ.value = sender.value
            textoValZ.text = String(sliderCamZ.value)
            dibujaCapsula()
        }
    }
    func dibujaCubo() {
        let sceneView = SCNView(frame: self.ImageView.frame)
        self.ImageView.addSubview(sceneView)
        
        let scene = SCNScene()
        sceneView.scene = scene
        
        let camara = SCNCamera()
        let camaraNode = SCNNode()
        camaraNode.camera = camara
        
        // Establecer posicion de la Camara // Usar el valor del Slider
        camaraNode.position = SCNVector3(x: sliderCamaraX.value, y: sliderCamY.value, z: sliderCamZ.value)
        
        let luz = SCNLight()
        luz.type = SCNLight.LightType(rawValue: tipoLuz!)
        luz.spotInnerAngle = 30.0
        luz.spotOuterAngle = 70.0
        luz.castsShadow = true
        
        let luzNode = SCNNode()
        luzNode.light = luz
        
        luzNode.position = SCNVector3(x: 1.5, y: 1.5, z: 1.5)
        //let cuboGeometria = SCNBox(width: 1.0, height: 1.0, length: 1.0, chamferRadius: 0.0)
        let capsule = SCNCapsule(capRadius: 0.2, height: 2.0)
        
        
        let cuboNode = SCNNode(geometry: capsule)
        let constraint = SCNLookAtConstraint(target: cuboNode)
        
        constraint.isGimbalLockEnabled = true
        camaraNode.constraints = [constraint]
        
        luzNode.constraints = [constraint]
        
        let geometriaPlano = SCNPlane(width: 50.0, height: 50.0)
        let planoNode = SCNNode(geometry: geometriaPlano)
        
        planoNode.eulerAngles = SCNVector3(x: GLKMathDegreesToRadians(-90), y: 0, z: 0)
        planoNode.position = SCNVector3(x: 0, y: -0.5, z: 0)
        
        let material = SCNMaterial()
        material.diffuse.contents = UIColor.systemYellow
        
        let material2 = SCNMaterial()
        material2.diffuse.contents = UIColor.black
        geometriaPlano.materials = [material]
        
        
        
        var geometries = [SCNSphere(radius: 1.0),
                          SCNPlane(width: 1.0, height: 1.5),
                          SCNBox(width: 1.0, height: 1.5, length: 2.0, chamferRadius: 0.0),
                          SCNPyramid(width: 2.0, height: 1.5, length: 1.0),
                          SCNCylinder(radius: 1.0, height: 1.5),
                          SCNCone(topRadius: 0.5, bottomRadius: 1.0, height: 1.5),
                          SCNTorus(ringRadius: 1.0, pipeRadius: 0.2),
                          SCNTube(innerRadius: 0.5, outerRadius: 1.0, height: 1.5),
                          SCNCapsule(capRadius: 0.5, height: 2.0)]
        var x:Float = 0.0
        for index in 0..<geometries.count {

          let hue:CGFloat = CGFloat(index) / CGFloat(geometries.count)
          let color = UIColor(hue: hue, saturation: 1.0, brightness: 1.0, alpha: 1.0)

          let geometry = geometries[index]
          geometry.firstMaterial?.diffuse.contents = color

          let node = SCNNode(geometry: geometry)
          node.position = SCNVector3(x: x, y: 0.0, z: 0.0)

            scene.rootNode.addChildNode(node)

          x += 2.5
        }
        
        // Se Agregan los Nodos
        scene.rootNode.addChildNode(luzNode)
        scene.rootNode.addChildNode(camaraNode)
        scene.rootNode.addChildNode(cuboNode)
        scene.rootNode.addChildNode(planoNode)
        
    }
    
    func dibujaCapsula() {
        let sceneView = SCNView(frame: self.ImageView.frame)
        self.ImageView.addSubview(sceneView)
        
        let scene = SCNScene()
        sceneView.scene = scene
        
        let camara = SCNCamera()
        let camaraNode = SCNNode()
        camaraNode.camera = camara
        
        // Establecer posicion de la Camara // Usar el valor del Slider
        camaraNode.position = SCNVector3(x: sliderCamaraX.value, y: sliderCamY.value, z: sliderCamZ.value)
        
        let luz = SCNLight()
        luz.type = SCNLight.LightType(rawValue: tipoLuz!)
        luz.spotInnerAngle = 30.0
        luz.spotOuterAngle = 70.0
        luz.castsShadow = true
        
        let luzNode = SCNNode()
        luzNode.light = luz
        
        luzNode.position = SCNVector3(x: 1.5, y: 1.5, z: 1.5)
        //let cuboGeometria = SCNBox(width: 1.0, height: 1.0, length: 1.0, chamferRadius: 0.0)
        let capsule = SCNCapsule(capRadius: 0.2, height: 2.0)
        
        
        let cuboNode = SCNNode(geometry: capsule)
        let constraint = SCNLookAtConstraint(target: cuboNode)
        
        constraint.isGimbalLockEnabled = true
        camaraNode.constraints = [constraint]
        
        luzNode.constraints = [constraint]
        
        let geometriaPlano = SCNPlane(width: 50.0, height: 50.0)
        let planoNode = SCNNode(geometry: geometriaPlano)
        
        planoNode.eulerAngles = SCNVector3(x: GLKMathDegreesToRadians(-90), y: 0, z: 0)
        planoNode.position = SCNVector3(x: 0, y: -0.5, z: 0)
        
        let material = SCNMaterial()
        material.diffuse.contents = UIColor.black
        
        let material2 = SCNMaterial()
        material2.diffuse.contents = UIColor.cyan
        geometriaPlano.materials = [material]
        
        
        
        
        
        // Se Agregan los Nodos
        scene.rootNode.addChildNode(luzNode)
        scene.rootNode.addChildNode(camaraNode)
        scene.rootNode.addChildNode(cuboNode)
        scene.rootNode.addChildNode(planoNode)
        
    }
   
    func pelotaAnimada() {
        let sceneView = SCNView(frame: self.ImageView.frame)
        self.ImageView.addSubview(sceneView)
        
        let scene = SCNScene()
        sceneView.scene = scene
        
        let sphere = SCNSphere(radius: 0.2)
        sphere.firstMaterial?.diffuse.contents = UIColor.red
        
        let pelota = SCNNode(geometry: sphere)
        //let constraint = SCNLookAtConstraint(target: pelota)
        
        let sphereNode = SCNNode(geometry: sphere)
        scene.rootNode.addChildNode(pelota)
        
        let moveUp = SCNAction.moveBy(x: 0.0, y: 1.0, z: 0.0, duration: 1.0)
        let moveDown = SCNAction.moveBy(x: 0.0, y: -1.0, z: 0.0, duration: 1.0)
        let sequence = SCNAction.sequence([moveUp,moveDown])
        pelota.runAction(sequence)
        
        sceneView.backgroundColor = UIColor.yellow

    }


    @IBAction func segment(_ sender: UISegmentedControl) {
        
        let indice : Int=segment.selectedSegmentIndex
        
        if indice == 0
        {
            dibujaCubo()
        }
        else if indice == 1
        {
           dibujaCapsula()
        }
        else if indice == 2
        {
           pelotaAnimada()
        }
    }
    
    
    @IBAction func segmentoTopoLuz(_ sender: UISegmentedControl) {
        let indice : Int = segment.selectedSegmentIndex
        
        if indice == 0
        {
             tipoLuz = "ambient"
        }
        else if indice == 1
        {
           tipoLuz = "directional"
        }
        else if indice == 2
        {
           tipoLuz = "omni"
        }
        else if indice == 3
        {
           tipoLuz = "spot"
        }
    }
    
}

