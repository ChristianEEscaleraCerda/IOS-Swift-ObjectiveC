//
//  ViewController1.swift
//  appTabAdd
//
//  Created by Guest User on 30/05/22.
//

import UIKit

class ViewController1: UIViewController {

    @IBOutlet weak var texto1: UITextField!
    
    @IBOutlet var but1: UIView!
    
    @IBOutlet weak var label1: UILabel!
    
    @IBOutlet weak var texto2: UITextField!
    
    @IBOutlet weak var slider: UISlider!
    
    var num:Int?
    
    @IBOutlet weak var segment: UISegmentedControl!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        slider.value = 20
        
    }
    

    @IBAction func slider(_ sender: UISlider) {
        texto1.text = "\(String(describing: lroundf(sender.value)))"
        num = Int(texto1.text!)
    }
    
    
    @IBAction func segment(_ sender: UISegmentedControl) {
        
        let indice : Int=segment.selectedSegmentIndex
        
        if indice == 0
        {
            texto2.text = String(num!, radix: 2)
        }
        else if indice == 1
        {
            texto2.text = String(num!, radix: 8)
        }
        else if indice == 2
        {
            texto2.text = String(num!, radix: 16).uppercased()
        }
            
    }
    @IBAction func but1(_ sender: UIButton) {
        label1.text = "Hola"
    }
}
    
    
