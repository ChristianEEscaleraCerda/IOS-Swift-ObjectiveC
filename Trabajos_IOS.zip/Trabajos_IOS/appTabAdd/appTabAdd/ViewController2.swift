//
//  ViewController2.swift
//  appTabAdd
//
//  Created by Guest User on 30/05/22.
//

import UIKit

class ViewController2: UIViewController {

    
    @IBOutlet weak var text1: UITextField!
    
    
    let banderas = [ "Mexico", "USA", "Ukrania", "Cuba", "Puero Rico"]
    
    let band = ["🇲🇽", "🇺🇸","🇺🇦","🇨🇺","🇵🇷"]
    
    var banderaSeleccionada : String?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        crearPickerViewBanderas()
        crearToolBar()
        self.view.backgroundColor = UIColor(patternImage: UIImage(named: "fondo6")!)
        
    }

    func crearPickerViewBanderas(){
        let banderasPicker = UIPickerView()
        banderasPicker.delegate = self
        text1.inputView = banderasPicker
    }
    
    func crearToolBar() {
        let toolBar = UIToolbar()
        toolBar.sizeToFit()
        toolBar.barTintColor = .yellow
        toolBar.tintColor = .black
        let butOk = UIBarButtonItem(title: "⬇️", style: .plain, target: self, action:#selector(ViewController2.dismissKeyBoard) )
        
        toolBar.setItems([butOk], animated: false)
        toolBar.isUserInteractionEnabled = true
        
        //OTRO BOTON
        _ = UIBarButtonItem()
        
        
        text1.inputAccessoryView = toolBar
        
    }
    @objc func dismissKeyBoard()
    {
        view.endEditing(true)
    }
    
    

}//FIN DEL VIEW CONTROLLER
extension CGFloat
{
    static func random() -> CGFloat
    {
        return CGFloat(arc4random()) / CGFloat(UInt32.max)
    }
}

extension UIColor{
    static func random() -> UIColor
    {
        return UIColor(red: .random(), green: .random(), blue: .random(), alpha: 1.0)
    }
}

extension ViewController2: UIPickerViewDelegate, UIPickerViewDataSource
{
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return banderas.count
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return banderas[row]
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        banderaSeleccionada = band[row]
        
        text1.backgroundColor = UIColor.random()
        text1.text = banderaSeleccionada
        
    }
    
    func pickerView(_ pickerView: UIPickerView, viewForRow row: Int, forComponent component: Int, reusing view: UIView?) -> UIView {
        var label : UILabel
        
        if let view = view as? UILabel
        {
            label = view
        }else {
            label = UILabel()
        }
        label.textColor = UIColor.random()
        label .textAlignment = .center
        label.font = UIFont(name :"Arial", size:24)
        label.text = banderas[row]
        
        return label
    }
    
}
