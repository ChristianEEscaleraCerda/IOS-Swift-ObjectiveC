//
//  graficos2D.swift
//  appTabAdd
//
//  Created by Guest User on 30/05/22.
//

import UIKit

class graficos2D: UIView {

    override func draw(_ rect: CGRect) {
       
        let canvas = UIGraphicsGetCurrentContext()
        
        canvas?.setLineWidth(5.0)
        
        //canvas?.setStrokeColor(UIColor.yellow.cgColor)
        
        let colorSpace = CGColorSpaceCreateDeviceRGB()
        let componentes:[CGFloat] = [CGFloat(Float.random(in: 0..<1)), CGFloat(drand48()),0.0,1.0]
        
        let color = CGColor(colorSpace: colorSpace, components: componentes)
        
        canvas?.setStrokeColor(color!)
        
        let ancho = rect.width
        let alto = rect.height
        canvas?.strokePath()
        
        print("Ancho = \(ancho)")
        print("Alto = \(alto)")
        
        let rectangulo = CGRect(x:50, y: 100, width:300, height:300)
                
                canvas?.addRect(rectangulo)
                canvas?.strokePath()
        
       
        
      
        canvas?.addLine(to: CGPoint(x:5, y:5))
        canvas?.addLine(to: CGPoint(x:canvas!.width/2, y:canvas!.height))
        canvas?.addLine(to: CGPoint(x:canvas!.width, y:0))
        canvas?.addLine(to: CGPoint(x:0, y:canvas!.height/2))
        canvas?.addLine(to: CGPoint(x:canvas!.width/2, y:canvas!.height/2))
        canvas?.addLine(to: CGPoint(x:0, y:0))
        
        canvas?.setFillColor(UIColor.yellow.cgColor)
        canvas?.fillPath()
                //Puerta
                canvas?.move(to: CGPoint(x:150, y:300))
                canvas?.addLine(to: CGPoint(x:250, y:300))
                canvas?.addLine(to: CGPoint(x:250, y:400))
                canvas?.addLine(to: CGPoint(x:150, y:400))
                canvas?.addLine(to: CGPoint(x:150, y:350))
                canvas?.setFillColor(UIColor.red.cgColor)
                canvas?.fillPath()
        
        //Techo
        canvas?.move(to: CGPoint(x:40, y:100))
        canvas?.addLine(to: CGPoint(x:400, y:100))
        canvas?.addLine(to: CGPoint(x:200, y:0))
        canvas?.addLine(to: CGPoint(x:40, y:100))
        canvas?.setFillColor(UIColor.red.cgColor)
        canvas?.fillPath()
                
                //DIBUJAR TEXTO
            
                //let font = UIFont.systemFont(ofSize: 30)
                 //   let font = UIFont(name: "Copperplate-Light", size: 30)
                let font = UIFont(name: "Arial", size: 30)
                    
                let stringAncho = NSAttributedString(string: "Ancho = \(ancho)", attributes: [NSAttributedString.Key.font: font!])
                stringAncho.draw(at: CGPoint(x: 10, y: 700))
                    
                let stringAlto = NSAttributedString(string: "Alto = \(alto)", attributes: [NSAttributedString.Key.font: font!])
                stringAlto.draw(at: CGPoint(x: 10, y: 750))

        
    }
}
