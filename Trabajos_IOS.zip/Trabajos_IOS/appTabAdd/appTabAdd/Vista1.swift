//
//  Vista1.swift
//  appTabAdd
//
//  Created by Guest User on 30/05/22.
//

import UIKit

class Vista1: UIView {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
