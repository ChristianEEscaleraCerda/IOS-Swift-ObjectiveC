//
//  ViewController.swift
//  appSQLite
//
//  Created by Daniel Saldivar on 09/06/22.
//

import UIKit
import SQLite3

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: UITableViewCell.CellStyle.default, reuseIdentifier: "cell")
        let pokemon: Pokemon
        pokemon = listaPokemon[indexPath.row]
        cell.textLabel?.text = pokemon.nombre
        return cell
    }
    
    var db: OpaquePointer?
    var listaPokemon = [Pokemon]()

    
    @IBOutlet weak var tableViewPokemon: UITableView!
    @IBOutlet weak var textFieldPokemon: UITextField!
    @IBOutlet weak var textFieldNumero: UITextField!
    
    @IBAction func buttonMostrar(_ sender: Any) {
        readValues()
    }
    @IBAction func buttonEliminar(_ sender: Any) {
    }
    
    @IBAction func buttonGuardar(_ sender: Any) {
        let nombre = textFieldPokemon.text?.trimmingCharacters(in: .whitespacesAndNewlines)
        let numero_pokedex = textFieldNumero.text?.trimmingCharacters(in: .whitespacesAndNewlines)
        
        if(nombre?.isEmpty)!{
            print("Pokemon esta vacio")
            return;
        }
        
        if(numero_pokedex?.isEmpty)!{
            print("El numero esta vacio")
            return;
        }
        
        var stmt: OpaquePointer?
        let insertQuery = "INSERT INTO Pokemon (nombre, numero_pokedex) VALUES (?, ?)"
        let updateQuery = ""
        
        if sqlite3_prepare(db, insertQuery, -1, &stmt, nil) != SQLITE_OK {
            print("Error con el query")
        }
        
        if sqlite3_bind_text(stmt, 1, nombre, -1, nil) != SQLITE_OK {
            print("Error poniendo el nombre")
        }
        
        if sqlite3_bind_int(stmt, 2, (numero_pokedex! as NSString).intValue) != SQLITE_OK {
            print("Error poniendo el numero")
        }
        
        if sqlite3_step(stmt) == SQLITE_DONE {
            print("Pokemon guardado exitosamente")
        }
        
        textFieldPokemon.text=""
        textFieldNumero.text=""
        
        readValues()
    }
    
    func tableView(_ _tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return listaPokemon.count
    }
    
    func readValues(){
        listaPokemon.removeAll()

        let queryString = "SELECT * FROM Pokemon"

        var stmt:OpaquePointer?

        if sqlite3_prepare(db, queryString, -1, &stmt, nil) != SQLITE_OK{
            let errmsg = String(cString: sqlite3_errmsg(db)!)
            print("Error preparando el insert: \(errmsg)")
            return
        }

        while(sqlite3_step(stmt) == SQLITE_ROW){
            let id = sqlite3_column_int(stmt, 0)
            let nombre = String(cString: sqlite3_column_text(stmt, 1))
            let numero_pokedex = sqlite3_column_int(stmt, 2)

            listaPokemon.append(Pokemon(id: Swift.Int(id), nombre: String(describing: nombre), numero_pokedex: Swift.Int(numero_pokedex)))
        }
        
        self.tableViewPokemon.reloadData()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let fileUrl = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false).appendingPathComponent("PokemonDatabase.sqlite")
        
        if sqlite3_open(fileUrl.path, &db) != SQLITE_OK{
            print("Error abriendo la base de datos")
            return
        }
        
        let createTableQuery = "CREATE TABLE IF NOT EXISTS Pokemon (id INTEGER PRIMARY KEY AUTOINCREMENT, nombre TEXT, numero_pokedex INTEGER)"
        
        if sqlite3_exec(db, createTableQuery, nil, nil, nil) != SQLITE_OK {
            print("Error creando la tabla")
            return
        }
        
        print("Todo esta correcto")
    }
}

