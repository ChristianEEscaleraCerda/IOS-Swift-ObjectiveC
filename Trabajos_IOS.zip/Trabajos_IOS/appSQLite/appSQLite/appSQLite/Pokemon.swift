//
//  Pokemon.swift
//  appSQLite
//
//  Created by Daniel Saldivar on 09/06/22.
//

import Foundation

class Pokemon {
 
    var id: Int
    var nombre: String?
    var numero_pokedex: Int
 
    init(id: Int, nombre: String?, numero_pokedex: Int){
        self.id = id
        self.nombre = nombre
        self.numero_pokedex = numero_pokedex
    }
}
