//
//  ViewController.swift
//  App3D_MoverCamara
//
//  Created by Guest User on 24/05/22.
//

import UIKit
import SceneKit // Se importa para el SCNView

class ViewController: UIViewController {
    
    
    @IBOutlet weak var textoValorX: UITextField!
    
    @IBOutlet weak var ImageView: UIImageView!
    
    @IBOutlet weak var sliderCamaraX: UISlider!
    
    @IBOutlet weak var sliderCamY: UISlider!
    
    @IBOutlet weak var sliderCamZ: UISlider!
    
    @IBOutlet weak var textoValY: UITextField!
    
    @IBOutlet weak var textoValZ: UITextField!
    
    
    @IBAction func sliderMoverCamaraX(_ sender: UISlider) {
        
        sliderCamaraX.value = sender.value
        textoValorX.text = String(sliderCamaraX.value)
        dibujaCubo()
        
    }
    
    @IBAction func sliderMoverCamaraY(_ sender: UISlider) {
        
        sliderCamY.value = sender.value
        textoValY.text = String(sliderCamY.value)
        dibujaCubo()
        
    }
    @IBAction func sliderMoverCamaraZ(_ sender: UISlider) {
        
        sliderCamZ.value = sender.value
        textoValZ.text = String(sliderCamZ.value)
        dibujaCubo()
        
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        dibujaCubo()
        
        
    }
    
    func dibujaCubo() {
        let sceneView = SCNView(frame: self.ImageView.frame)
        self.ImageView.addSubview(sceneView)
        
        let scene = SCNScene()
        sceneView.scene = scene
        
        let camara = SCNCamera()
        let camaraNode = SCNNode()
        camaraNode.camera = camara
        
        // Establecer posicion de la Camara // Usar el valor del Slider
        camaraNode.position = SCNVector3(x: sliderCamaraX.value, y: sliderCamY.value, z: sliderCamZ.value)
        
        let luz = SCNLight()
        luz.type = SCNLight.LightType.omni
        luz.spotInnerAngle = 30.0
        luz.spotOuterAngle = 70.0
        luz.castsShadow = true
        
        let luzNode = SCNNode()
        luzNode.light = luz
        
        luzNode.position = SCNVector3(x: 1.5, y: 1.5, z: 1.5)
        //let cuboGeometria = SCNBox(width: 1.0, height: 1.0, length: 1.0, chamferRadius: 0.0)
        let capsule = SCNCapsule(capRadius: 0.2, height: 2.0)
        
        
        let cuboNode = SCNNode(geometry: capsule)
        let constraint = SCNLookAtConstraint(target: cuboNode)
        
        constraint.isGimbalLockEnabled = true
        camaraNode.constraints = [constraint]
        
        luzNode.constraints = [constraint]
        
        let geometriaPlano = SCNPlane(width: 50.0, height: 50.0)
        let planoNode = SCNNode(geometry: geometriaPlano)
        
        planoNode.eulerAngles = SCNVector3(x: GLKMathDegreesToRadians(-90), y: 0, z: 0)
        planoNode.position = SCNVector3(x: 0, y: -0.5, z: 0)
        
        let material = SCNMaterial()
        material.diffuse.contents = UIColor.systemYellow
        
        let material2 = SCNMaterial()
        material2.diffuse.contents = UIColor.black
        geometriaPlano.materials = [material]
        
        
        
        var geometries = [SCNSphere(radius: 1.0),
                          SCNPlane(width: 1.0, height: 1.5),
                          SCNBox(width: 1.0, height: 1.5, length: 2.0, chamferRadius: 0.0),
                          SCNPyramid(width: 2.0, height: 1.5, length: 1.0),
                          SCNCylinder(radius: 1.0, height: 1.5),
                          SCNCone(topRadius: 0.5, bottomRadius: 1.0, height: 1.5),
                          SCNTorus(ringRadius: 1.0, pipeRadius: 0.2),
                          SCNTube(innerRadius: 0.5, outerRadius: 1.0, height: 1.5),
                          SCNCapsule(capRadius: 0.5, height: 2.0)]
        var x:Float = 0.0
        for index in 0..<geometries.count {

          let hue:CGFloat = CGFloat(index) / CGFloat(geometries.count)
          let color = UIColor(hue: hue, saturation: 1.0, brightness: 1.0, alpha: 1.0)

          let geometry = geometries[index]
          geometry.firstMaterial?.diffuse.contents = color

          let node = SCNNode(geometry: geometry)
          node.position = SCNVector3(x: x, y: 0.0, z: 0.0)

            scene.rootNode.addChildNode(node)

          x += 2.5
        }
        
        // Se Agregan los Nodos
        scene.rootNode.addChildNode(luzNode)
        scene.rootNode.addChildNode(camaraNode)
        scene.rootNode.addChildNode(cuboNode)
        scene.rootNode.addChildNode(planoNode)
        
        
        
    }

   /* @IBAction func butAnimar(_ sender: Any) {
        let moveUp = SCNAction.moveByX(0.0, y: 1.0, z: 0.0, duration: 1.0)
        let moveDown = SCNAction.moveByX(0.0, y: -1.0, z: 0.0, duration: 1.0)
        let sequence = SCNAction.sequence([moveUp,moveDown])
        geometries.runAction(sequence)
    }*/
    
}

