//
//  ContentView.swift
//  appSlider
//
//  Created by Guest User on 01/06/22.
//

import SwiftUI

struct ContentView: View {
    
    @State private var celsius : Double = 0.0
    @State private var far : Double = 0.0
    @State private var kelvin : Double = 0.0
    
    var body: some View {
        
        ZStack{
            Color.yellow.ignoresSafeArea()
            VStack{
                Slider(value: $celsius, in: -100...100)
                Text("\(celsius, specifier:"%.2f") Celsius es = \(celsius * 9/5+32,specifier:"%.1f")Farenheit")
                    .foregroundColor(.black).bold()
                    .padding(.horizontal,10)
                    .background(Capsule().stroke(Color.blue, lineWidth: 2))
            }
        }.background(Color(red: 0.2, green: 0.9, blue: 0.6))
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
