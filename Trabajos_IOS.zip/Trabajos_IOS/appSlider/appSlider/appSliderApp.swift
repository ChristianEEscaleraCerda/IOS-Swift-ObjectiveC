//
//  appSliderApp.swift
//  appSlider
//
//  Created by Guest User on 01/06/22.
//

import SwiftUI

@main
struct appSliderApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
