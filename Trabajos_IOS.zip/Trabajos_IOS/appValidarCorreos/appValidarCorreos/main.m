//
//  main.m
//  appValidarCorreos
//
//  Created by Guest User on 04/04/22.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        
        printf("\n\nVALIDAR CORREO");
        NSString *correo = @"erick.guerrero@mail.com.mx.lag";
        
        
        correo = [correo lowercaseString];
        NSLog(@"Validar Correo");
        NSString *regex = @"^[\\w-]+(\\.[\\w-_]+)*@[A-Za-z0-9]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
        //NSString *regex = @"^[\\w-]+(\\.[\\w-_]+)@[A-Za-z0-9]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})*$";
        //NSString *regex = @"^[\\w-]+(\\.[\\w-_]+)*@[A-Za-z0-9]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
        // w TODO LO QUE SEA PALABRA
        
        
        
        NSError *error1 = NULL;
        NSRegularExpression *regex1 = [NSRegularExpression regularExpressionWithPattern:regex options:NSRegularExpressionCaseInsensitive error:&error1];
        
        NSTextCheckingResult *match = [regex1 firstMatchInString:correo options:0 range:NSMakeRange(0, correo.length)];
        if(match){
            NSLog(@"%@  : CORREO VALIDO",correo);
        }else{
            NSLog(@"%@  : CORREO NO VALIDO",correo);
        }
        
        
    }
    return 0;
}
