//
//  main.m
//  appBloques
//
//  Created by Guest User on 30/03/22.
//

#import <Foundation/Foundation.h>
double (^multiplyTwoValues)(double, double) =
^(double firstValue, double secondValue) {
   return firstValue * secondValue;
};

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        double result = multiplyTwoValues(2,4);
        NSLog(@"The result is %f", result);
    }
    return 0;
}
