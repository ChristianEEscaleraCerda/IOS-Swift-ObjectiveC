//
//  SceneDelegate.h
//  AppIOS1
//
//  Created by Usuario invitado on 22/03/22.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

