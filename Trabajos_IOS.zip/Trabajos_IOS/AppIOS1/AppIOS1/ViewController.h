//
//  ViewController.h
//  AppIOS1
//
//  Created by Usuario invitado on 22/03/22.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

{
    // __weak IBOutlet UITextField *texto1; //_texto1;
    
    __weak IBOutlet UILabel *label1;
}

@property (weak, nonatomic) IBOutlet UITextField * texto1;

- (IBAction)botonSaludad:(id)sender;



@end

