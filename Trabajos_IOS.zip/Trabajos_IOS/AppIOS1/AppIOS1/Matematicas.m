//
//  Matematicas.m
//  AppMatematicas
//
//  Created by bigsur on 07/03/21.
//

#import "Matematicas.h"

@implementation Matematicas
- (int)max:(int)num1 andNum2:(int)num2 {

   /* local variable declaration */
   int result;
 
   if (num1 > num2) {
      result = num1;
   } else {
      result = num2;
   }
 
   return result;
}

-(NSNumber *) multiplicarA:(NSNumber *)a conB:(NSNumber *)b {
    float n1 = [a floatValue];
    float n2 = [b floatValue];
    float result = n1 * n2;
    NSNumber *r = [NSNumber numberWithFloat:result];
    return r;
}

-(void) multiplicarA:(NSNumber *)a conB:(NSNumber *)b resultado:(NSNumber *) res {
    float n1 = [a floatValue];
    float n2 = [b floatValue];
    res = [NSNumber numberWithFloat:n1 * n2];
}

-(void) multiplicarA_:(NSNumber *)a conB:(NSNumber *)b resultado:(double *) res {
    float n1 = [a doubleValue];
    float n2 = [b doubleValue];
    *res = n1 * n2;
}
    
-(int)factorial:(int)n {
    if (n == 0 || n == 1){
        return 1;
    }
    Matematicas *matematicas = [[Matematicas alloc]init];
    return n * [matematicas factorial: n - 1];
}

-(int) factorialR:(int) n{
    if ( n == 0 || n == 1 ){
        return 1;
    } else {
        return n * [self factorialR: n - 1];
    }
}

-(BOOL)esPrimo:(int)n{
    int div = 2;
    while ( div < n ){
        if ( n % div == 0 )
            return NO;
        ++div;
    }
    return YES;
}

-(int)sumar:(int)n1 conN2:(int)n2{
    return n1 + n2;
}

-(int)restar:(int)n1 conN2:(int)n2{
    return n1 - n2;
}

-(int)dividir:(int)n1 conN2:(int)n2{
    return n1 / n2;
}

-(int)obtenerResiduo:(int)n1 conN2:(int)n2{
    return n1 % n2;
}

-(void)menu{
    NSLog(@".:: App Matematicas ::."
          "\n1️⃣ Multiplicar"
          "\n2️⃣ Valor máximo"
          "\n3️⃣ Factorial"
          "\n4️⃣ Primo"
          "\n5️⃣ Suma"
          "\n6️⃣ Resta"
          "\n7️⃣ División"
          "\n8️⃣ Residuo"
          "\n9️⃣ Euler"
          "\n1️⃣0️⃣ Esponencial"
          "\n1️⃣1️⃣ Seno"
          "\n1️⃣2️⃣ Coseno"
          "\n\nIngrese una opción: ");
}

-(float) euler {
    float euler = 0.0;
    int cont = 0;
    while( euler <= exp (1) ){
        euler += ( 1.0 / [self factorialR: cont++] );
    }
    return euler;
}

-(float) exponencial: (float) x{
    float euler = 0.0;
    int cont = 0;
    while( euler <= exp(x) ){
        euler += ( pow( x, cont ) / [ self factorialR: cont ] );
        cont++;
    }
    return euler;
}

-(float) seno: ( float ) x {
    float senx = 0.0;
    for ( int i = 0; i <= 8; i++ ) {
        senx = senx + pow ( -1, i ) * pow ( x, 2 * i + 1 ) / [ self factorialR:( 2 * i + 1 )];
    }
    return senx ;
}

-(float) coseno: ( float ) x {
    float cosx = 0.0;
    for ( int i = 0; i <= 8; i++ ) {
        cosx = cosx + pow ( -1, i ) * pow ( x, 2 * i) / [ self factorialR:( 2 * i)];
    }
    return cosx;
}

@end
