//
//  ViewController.m
//  AppIOS1
//
//  Created by Usuario invitado on 22/03/22.
//

#import "ViewController.h"
#import "Matematicas.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UITextField *textoX;
@property (weak, nonatomic) IBOutlet UITextField *textoY;
@property (weak, nonatomic) IBOutlet UILabel *resultado;
@property (weak, nonatomic) IBOutlet UILabel *resultado2;
@property (weak, nonatomic) IBOutlet UIStepper *stepper1;
@property (weak, nonatomic) IBOutlet UISlider *slider;
@property (weak, nonatomic) IBOutlet UILabel *labregex;

//@property (weak, nonatomic) IBOutlet UITextField *texto1;
- (IBAction)texto1:(id)sender;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
   // [_texto1 becomeFirstResponder];
    
}

NSString * cadena = @"HOLA ";

- (IBAction)botonSaludad:(id)sender {
    
    label1.text = [cadena stringByAppendingString:_texto1.text];
    
    
}
- (IBAction)butRegex:(id)sender {
    
    //NSString *cadenaPrueba = @"Tecnològico de la laguna" ;
    NSString *cadPrueba =  _texto1.text;
    //NSLog(@"Cadena de prueba : %@",cadPrueba);
    NSError *error = nil;
    
    
    NSMutableString *cadenaPatron = [[NSMutableString alloc]init];
    
   // [cadenaPatron appendString:@"\\b(a|b)(c|d)\\b"];
    
    [cadenaPatron appendString:@"([aeiou])"];
    
    NSRegularExpression *regex = [NSRegularExpression regularExpressionWithPattern:cadenaPatron options:NSRegularExpressionCaseInsensitive error:&error];
    
    NSArray *matches = [regex matchesInString:cadPrueba options:0 range:NSMakeRange(0, cadPrueba.length)];
    
    for( NSTextCheckingResult *matchResult in matches){
        
        NSString *match = [cadPrueba substringWithRange:matchResult.range];
        NSLog(@"Coincidencia = @%@", match);
        self.labregex = [NSString stringWithFormat:@"%@",match];
}
}
- (IBAction)botonPotencia:(id)sender {
    float x = _textoX.text.doubleValue;
    int pot = pow(x,_textoY.text.doubleValue);
    
    self.resultado.text =[NSString stringWithFormat:@"%d",(int) pot];
    
    //ceil y floor
    
}
- (IBAction)botonFactorial:(id)sender {
    Matematicas *mate = [[Matematicas alloc] init];
    double res = [mate factorial:_textoX.text.doubleValue];
    
    _resultado2.text = [NSString stringWithFormat:@"%.0lf",res];
}
- (IBAction)butStepper:(id)sender {
    [_textoX setText:[NSString stringWithFormat:@"%d ",(int) _stepper1.value]];
}
- (IBAction)slider:(id)sender {
    [_textoY setText:[NSString stringWithFormat:@"%d ",(int) _slider.value]];
}

//- (IBAction)butAlert:(id)sender {
    
- (IBAction)butAlert:(UIButton *)sender {
    UIAlertController *alerta = [UIAlertController alertControllerWithTitle:@"Alerta en IOS" message:@"Utilizando una alerta" preferredStyle:UIAlertControllerStyleAlert];
    
         UIAlertAction *al = [UIAlertAction actionWithTitle:@"Ok" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){}];
                                 [alerta addAction:al];
                                 [self presentViewController:alerta animated:YES completion:Nil];
}


- (IBAction)texto1:(id)sender {
}
@end
