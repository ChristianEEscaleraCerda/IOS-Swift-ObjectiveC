//
//  Matematicas.h
//  AppMatematicas
//
//  Created by bigsur on 07/03/21.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Matematicas : NSObject
- (int)max:(int)num1 andNum2:(int)num2;
// Sobrecarga de métodos
-(NSNumber *) multiplicarA:(NSNumber *)a conB:(NSNumber *)b;
-(void) multiplicarA:(NSNumber *)a conB:(NSNumber *)b resultado:(NSNumber *) res;
-(void) multiplicarA_:(NSNumber *)a conB:(NSNumber *)b resultado:(double *) res;
-(int)factorial:(int)n;
-(BOOL)esPrimo:(int)n;
-(int) sumar:(int)n1 conN2:(int)n2;
-(int) restar:(int)n1 conN2:(int)n2;
-(int) dividir:(int)n1 conN2:(int)n2;
-(int) obtenerResiduo:(int)n1 conN2:(int)n2;
-(void) menu;
-(int) factorialR:(int) n;
-(float) euler;
-(float) exponencial: (float) x;
-(float) seno: ( float ) x;
-(float) coseno: ( float ) x;
@end

NS_ASSUME_NONNULL_END
