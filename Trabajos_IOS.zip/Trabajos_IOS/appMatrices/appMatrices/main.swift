//
//  main.swift
//  appMatrices
//
//  Created by Guest User on 03/05/22.
//

import Foundation

func main() -> (){
    print("Multiplicaciòn de Matrices")
    print("\n")
    let matrizA = [[1,2,3],[4,5,6]]
    let matrizB = [[1,2],[3,4],[5,6]]
    
    print("Matriz A")
    imprimir(matrizA)
    print("\n Matriz B")
    imprimir(matrizB)
    
  /*// Si el número de columnas de la matriz A es diferente a la Matriz B
    if matrizA[0].count != matrizB.count {
        print( "No se pueden multiplicar" )
    }
    //Contamos los renglones en A
    let renA = matrizA.count
    
    var res:[[Int]] = [[Int]]( repeating: [Int]( repeating: 0, count: renA ), count: renA )
    // Recorremos las columnas de la matriz resultante
    for i in 0 ..< res.count {
        // Recorremos las columnas de la matriz A
        for j in 0 ..< matrizA.count {
            // Recorremos las columnas de la matriz B
            for k in 0 ..< matrizB.count {
                res[i][j] += matrizA[i][k] * matrizB[k][j]
            }
        }
    }*/
    
let res = multiplicar(matrizA,matrizB)
print("Matriz Res")
imprimir(res)
    
}

func imprimir(_ matrix:[[Int]])
{
    for array in matrix {
            print(array)
    }
}


func multiplicar (_ matrizA:[[Int]], _ matrizB: [[Int]]) -> [[Int]]{
    
    // Si el número de columnas de la matriz A es diferente a la Matriz B
    if matrizA[0].count != matrizB.count {
        print( "No se pueden multiplicar" )
        return [[]] //se regresa una mariz vacia
    }
    //Contamos los renglones en A
    let tam = matrizA.count
    
    var res:[[Int]] = [[Int]]( repeating: [Int]( repeating: 0, count: tam ), count: tam )
    // Recorremos las columnas de la matriz resultante
    for i in 0 ..< res.count {
        // Recorremos las columnas de la matriz A
        for j in 0 ..< matrizA.count {
            // Recorremos las columnas de la matriz B
            for k in 0 ..< matrizB.count {
                res[i][j] += matrizA[i][k] * matrizB[k][j]
            }
        }
    }
    return res
    
}

main()
