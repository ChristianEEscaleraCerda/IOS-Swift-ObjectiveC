//
//  SceneDelegate.h
//  appPickerView1
//
//  Created by Guest User on 05/04/22.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

