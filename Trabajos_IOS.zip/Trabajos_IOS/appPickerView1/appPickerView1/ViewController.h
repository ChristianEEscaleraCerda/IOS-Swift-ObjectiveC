//
//  ViewController.h
//  appPickerView1
//
//  Created by Guest User on 05/04/22.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController <UIPickerViewDelegate, UIPickerViewDataSource>

@property (weak, nonatomic) IBOutlet UITextField *texto1;
@property (weak, nonatomic) IBOutlet UILabel *lab1;
@property (weak, nonatomic) IBOutlet UIPickerView *picker1;


@property (strong, nonatomic) NSArray *pais;
@property (strong, nonatomic) NSArray *tipoCambio;

@end

