//
//  ViewController.m
//  appPickerView1
//
//  Created by Guest User on 05/04/22.
//

#import "ViewController.h"

@interface ViewController ()
{
    NSArray *paises;
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    paises = @[@"Australia",@"China",@"Japon",@"Inglaterra",@"Mèxico"];
    
    _tipoCambio = [[NSArray alloc] initWithObjects:[NSNumber numberWithFloat:0.992],[NSNumber numberWithFloat:6.5938],[NSNumber numberWithFloat:0.727],[NSNumber numberWithFloat:0.6206],[NSNumber numberWithFloat:81.57],[NSNumber numberWithFloat:20.335], nil];
    
    self.picker1.delegate = self;
    self.picker1.dataSource = self;
    _lab1.text = paises[0];
}
-
 (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView{
    return 1;
}
-(NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
    return [paises count];
}
-(NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component{
    return paises[row];
}
-(void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component{
    float divisa = [[_tipoCambio objectAtIndex:row]floatValue];
    
    float dolares = [_texto1.text floatValue];
    float resul = dolares * divisa;
    
    NSString *resultCad = [[NSString alloc] initWithFormat:@"%.2f  USD = %.2f  %@",dolares,resul,[paises objectAtIndex:row]];
    
    _lab1.text = resultCad;
    
}


@end
