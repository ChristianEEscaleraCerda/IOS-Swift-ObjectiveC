import Foundation

func Burbuja(arrayN: Array<Int>)-> Array<Int>
{
    var arrayAux : [Int] = []
    if arrayN.isEmpty
    {
        return arrayAux
    }
    arrayAux = arrayN
    for _ in 0..<arrayN.count-1
    {
        for j in 0..<arrayN.count-1{
            var aux = 0
            if(arrayAux[j] > arrayAux[j+1])
            {
            aux = arrayAux[j]
            arrayAux[j] = arrayAux[j+1]
            arrayAux[j+1] = aux
            }
        }
    }
    return arrayAux
}

//PASE POR REFERENCIA DE UN ARREGLO

func Burbuja(vec:inout Array<Int>)
{
    var aux = 0
    for _ in 0..<vec.count-1
    {
        for j in 0..<vec.count-1 {
            if(vec[j] > vec[j+1])
            {
            aux = vec[j]
            vec[j] = vec[j+1]
            vec[j+1] = aux
            }
        }
    }
}

var aleatorios:Int
var arrayNumeros:[Int]=[]
for _ in 1...10
{
    arrayNumeros.append(Int.random(in: 10...100))
}

print("Datos Desordenaos")
print(arrayNumeros)

arrayNumeros = Burbuja(arrayN: arrayNumeros)

print("\n Datos Ordenados")
print(arrayNumeros)
arrayNumeros.removeAll()

for _ in 1...10
{
    arrayNumeros.append(Int.random(in: 10...100))
}
print("Datos Desordenaos")
print(arrayNumeros)

print("\n Datos Ordenados")
arrayNumeros = Burbuja(arrayN: arrayNumeros)
print(arrayNumeros)
