//
//  JuegoCartaDeck.h
//  JuegoCartas_V1
//
//  Created by Roberto Esquivel Troncoso on 23/10/22.
//

#import <Foundation/Foundation.h>
#import "Deck.h"
#import "JuegoCarta.h"
NS_ASSUME_NONNULL_BEGIN

@interface JuegoCartaDeck : Deck//NSObject

@end

NS_ASSUME_NONNULL_END
